package com.math.operations;

public class Multiplication {
    public static int multiply(int a, int b) {
        return a * b;
    }
}
