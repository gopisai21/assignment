package com.math.operations;

public class MathOperations {
           public static void main(String[] args) {
	        int result1 = Addition.add(5, 3);
	        int result2 = Subtraction.subtract(10, 2);
	        int result3 = Multiplication.multiply(4, 6);
	        int result4 = Division.divide(10, 2); 

	        System.out.println("Addition: " + result1);
	        System.out.println("Subtraction: " + result2);
	        System.out.println("Multiplication: " + result3);
	        System.out.println("Division: " + result4); 
	    }
	}