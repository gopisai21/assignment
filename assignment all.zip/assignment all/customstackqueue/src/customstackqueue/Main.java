package customstackqueue;

public class Main {

	public static void main(String[] args) {
		
		        Customstack stack = new Customstack();

		        // Pushing integers onto the stack
		        stack.Push(1);
		        stack.Push(2);
		        stack.Push(3);

		        // Popping and displaying integers until the stack is empty
		        while (!stack.IsEmpty()) {
		            System.out.println("Popped: " + stack.Pop());
		        }
	}   
		
}


