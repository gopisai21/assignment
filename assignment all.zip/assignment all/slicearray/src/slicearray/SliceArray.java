package slicearray;

public class SliceArray {
	public static void main(String[] args) {
	    int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	    int startIndex = 3;
	    int endIndex = 7;
	    int[] slicedArray = sliceArray(arr, startIndex, endIndex);

	    System.out.print("Original Array: ");
	    for (int num : arr) {
	        System.out.print(num + " ");
	    }

	    System.out.println("\nSliced Array: ");
	    for (int num : slicedArray) {
	        System.out.print(num + " ");
	    }
	}

	public static int[] sliceArray(int[] arr, int startIndex, int endIndex) {
	    if (startIndex < 0 || endIndex > arr.length - 1 || startIndex > endIndex) {
	        throw new IndexOutOfBoundsException("Invalid indices");
	    }

	    int[] slicedArray = new int[endIndex - startIndex + 1];
	    for (int i = 0, j = startIndex; i < slicedArray.length && j <= endIndex; i++, j++) {
	        slicedArray[i] = arr[j];
	    }
	    return slicedArray;
	}

}
