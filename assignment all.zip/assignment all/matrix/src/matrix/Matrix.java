package matrix;

public class Matrix {
        private int rows;
	    private int columns;
	    private int[][] matrix;
          public Matrix(int rows, int columns) {
	        this.rows = rows;
	        this.columns = columns;
	        matrix = new int[rows][columns];
	    }

	    public void fillMatrix(int value) {
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < columns; j++) {
	                matrix[i][j] = value;
	            }
	        }
	    }

	 public int[][] getMatrix() {
	        return matrix;
	    }

	    public static void main(String[] args) {
	        Matrix myMatrix = new Matrix(3, 3);
	        myMatrix.fillMatrix(5);

	        for (int[] row : myMatrix.getMatrix()) {
	            for (int element : row) {
	                System.out.print(element + " ");
	            }
	            System.out.println();
	        }
	    }
	}


