package linearsearch;

public class LinearSearch {
	public static void main(String[] args) {
	    int[] arr = {2, 5, 9, 3, 7, 4, 1};
	    int target = 7;
	    int result = performLinearSearch(arr, target);
	    System.out.println("Index of " + target + " in the array: " + result);
	}

	public static int performLinearSearch(int[] arr, int target) {
	    for (int i = 0; i < arr.length; i++) {
	        if (arr[i] == target) {
	            return i;
	        }
	    }
	    return -1;
	}
}
