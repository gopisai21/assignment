package stringmanipulator;

public class StringManipulator {
	public static void main(String[] args) {
	    String str1 = "Hello";
	    String str2 = "World";
	    int middleLength = 4;

	    String result = middleSubstring(str1, str2, middleLength);
	    System.out.println("Middle Substring of length " + middleLength + ": " + result);
	}

	public static String middleSubstring(String str1, String str2, int middleLength) {
	    String concatenated = concatenateAndReverse(str1, str2);

	    if (concatenated.length() < middleLength || middleLength < 1) {
	        return "Invalid middle length";
	    }

	    int startIndex = (concatenated.length() - middleLength) / 2;
	    int endIndex = startIndex + middleLength;
	    return concatenated.substring(startIndex, endIndex);
	}

	private static String concatenateAndReverse(String str1, String str2) {
	    return new StringBuilder(str1).append(str2).reverse().toString();
	}

}
