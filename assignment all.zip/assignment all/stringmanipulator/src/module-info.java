/**
 * 
 */
/**
 * 
 */
module stringmanipulator {
}