/**
 * 
 */
/**
 * 
 */
module customqueue2 {
}