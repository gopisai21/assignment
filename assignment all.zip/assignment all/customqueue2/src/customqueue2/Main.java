package customqueue2;

public class Main {

	public static void main(String[] args) {
		CustomQueue<Object> queue = new CustomQueue<>();

		        // Enqueuing strings and integers
		        queue.Enqueue("Hello");
		        queue.Enqueue(123);
		        queue.Enqueue("World");

		        // Dequeuing and displaying elements
		        while (!queue.IsEmpty()) {
		            System.out.println("Dequeued: " + queue.Dequeue());
		        }
		    }
		}


