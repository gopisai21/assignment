package fibonacci;

public class Fibonacci {
	public static void main(String[] args) {
	    int n = 10;
	    int[] fibArray = fibonacciSequence(n);

	    System.out.print("Fibonacci Sequence of first " + n + " elements: ");
	    for (int num : fibArray) {
	        System.out.print(num + " ");
	    }
	}

	public static int[] fibonacciSequence(int n) {
	    if (n <= 0) {
	        return new int[0];
	    }
	    int[] fibArray = new int[n];
	    fibArray[0] = 0;
	    fibArray[1] = 1;
	    for (int i = 2; i < n; i++) {
	        fibArray[i] = fibArray[i - 1] + fibArray[i - 2];
	    }
	    return fibArray;
	}

}
